package com.example.SimpleCrudeOperations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleCrudeOperationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
