package com.example.SimpleCrudeOperations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleCrudeOperationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleCrudeOperationsApplication.class, args);
	}

}
